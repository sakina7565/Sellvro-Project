import User from '../models/User.js'
import Role from '../models/Role.js'
import BusinessProfile from '../models/BusinessProfile.js'
import AdminNotification from '../models/AdminNotification.js'
import Order from '../models/Order.js'
import Product from '../models/Product.js'
import Review from '../models/Review.js'
import Country from '../models/Country.js'
import Location from '../models/Location.js'
import { signToken } from '../middleware/auth.js'
import { setAuthCookie, setImpersonatorCookie, readAuthToken } from '../utils/authCookie.js'
import { createNotification } from '../utils/notifications.js'
import { sendSupplierWarningEmail, sendSupplierSuspensionEmail } from '../utils/emailService.js'

const formatJoined = (date) =>
  new Date(date).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })

export const listPendingSuppliers = async (_req, res) => {
  try {
    const users = await User.find({ role: 'supplier', status: 'pending_approval' }).sort({ createdAt: -1 })
    const profiles = await BusinessProfile.find({
      user: { $in: users.map((u) => u._id) },
      profileType: 'supplier',
    })
    const profileMap = new Map(profiles.map((p) => [p.user.toString(), p]))

    const data = users.map((user) => {
      const profile = profileMap.get(user._id.toString())
      return {
        id: user._id.toString(),
        supplier: user.fullName,
        fullName: user.fullName,
        email: user.email,
        businessName: profile?.businessName || user.fullName,
        businessDescription: profile?.businessDescription || 'No description provided.',
        businessCategory: profile?.businessCategory || '—',
        businessEmail: profile?.businessEmail || user.email,
        businessPhone: profile?.businessPhone || '—',
        businessAddress: profile?.businessAddress || '—',
        country: profile?.country || '',
        city: profile?.city || '',
        orderType: profile?.orderType || 'Standard',
        location: [profile?.city, profile?.country].filter(Boolean).join(', ') || '—',
        category: profile?.businessCategory || '—',
        paymentProvider: profile?.paymentProvider || 'Not Set',
        accNumber: profile?.accNumber ? `•••• ${profile.accNumber.slice(-4)}` : 'Not Set',
        cardDate: profile?.cardDate || '—',
        joined: formatJoined(user.createdAt),
        rawJoined: user.createdAt,
        status: 'Pending',
        role: 'supplier',
      }
    })

    return res.json({ data })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to load pending suppliers.' })
  }
}

export const listPendingUsers = async (_req, res) => {
  try {
    const users = await User.find({ role: 'user', status: 'pending_approval' }).sort({ createdAt: -1 })
    const profiles = await BusinessProfile.find({
      user: { $in: users.map((u) => u._id) },
      profileType: 'user',
    })
    const profileMap = new Map(profiles.map((p) => [p.user.toString(), p]))

    const data = users.map((user) => {
      const profile = profileMap.get(user._id.toString())
      return {
        id: user._id.toString(),
        fullName: user.fullName,
        email: user.email,
        businessName: profile?.businessName || '—',
        businessDescription: profile?.businessDescription || 'No description provided.',
        businessCategory: profile?.businessCategory || 'General Buyer',
        businessEmail: profile?.businessEmail || user.email,
        businessPhone: profile?.businessPhone || '—',
        businessAddress: profile?.businessAddress || '—',
        country: profile?.country || '',
        city: profile?.city || '',
        orderType: profile?.orderType || 'Standard',
        wallet: `$${Number(user.walletBalance || 0).toLocaleString()}`,
        walletBalance: user.walletBalance || 0,
        location: [profile?.city, profile?.country].filter(Boolean).join(', ') || '—',
        paymentProvider: profile?.paymentProvider || 'Not Set',
        accNumber: profile?.accNumber ? `•••• ${profile.accNumber.slice(-4)}` : 'Not Set',
        cardDate: profile?.cardDate || '—',
        joined: formatJoined(user.createdAt),
        rawJoined: user.createdAt,
        status: 'Pending',
        role: 'user',
      }
    })

    return res.json({ data })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to load pending users.' })
  }
}

export const listApprovedSuppliers = async (_req, res) => {
  try {
    const users = await User.find({ role: 'supplier', status: 'approved' }).sort({ createdAt: -1 })
    const profiles = await BusinessProfile.find({
      user: { $in: users.map((u) => u._id) },
      profileType: 'supplier',
    })
    const profileMap = new Map(profiles.map((p) => [p.user.toString(), p]))

    const data = users.map((user) => {
      const profile = profileMap.get(user._id.toString())
      return {
        id: user._id.toString(),
        supplier: user.fullName,
        location: [profile?.city, profile?.country].filter(Boolean).join(', ') || '—',
        orders: 0,
        revenue: '$0',
        payout: 'weekly',
        warn: 0,
        joined: formatJoined(user.createdAt),
        status: 'Approved',
      }
    })

    return res.json({ data })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to load suppliers.' })
  }
}

export const listApprovedUsers = async (_req, res) => {
  try {
    const users = await User.find({ role: 'user', status: { $in: ['approved', 'suspended'] } }).sort({
      createdAt: -1,
    })

    const data = users.map((user) => ({
      id: user._id.toString(),
      email: user.email,
      wallet: '$0',
      joined: formatJoined(user.createdAt),
      status: user.status === 'suspended' ? 'suspended' : 'approved',
    }))

    return res.json({ data })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to load users.' })
  }
}

export const approveAccount = async (req, res) => {
  try {
    const { id } = req.params
    const user = await User.findById(id)

    if (!user || !['supplier', 'user'].includes(user.role)) {
      return res.status(404).json({ message: 'Account not found.' })
    }

    user.status = 'approved'
    await user.save()

    await BusinessProfile.findOneAndUpdate(
      { user: user._id },
      { status: 'approved' },
      { new: true },
    )

    return res.json({
      message: `${user.role === 'supplier' ? 'Supplier' : 'User'} approved successfully.`,
      user: user.toSafeObject(),
    })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to approve account.' })
  }
}

export const listAdminUsers = async (_req, res) => {
  try {
    const users = await User.find({ role: 'admin' }).sort({ createdAt: -1 })
    const roleIds = [...new Set(users.map((u) => u.adminRoleId?.toString()).filter(Boolean))]
    const roles = await Role.find({ _id: { $in: roleIds } })
    const roleMap = new Map(roles.map((r) => [r._id.toString(), r.name]))

    const data = users.map((user) => ({
      id: user._id.toString(),
      name: user.fullName,
      email: user.email,
      adminRoleId: user.adminRoleId?.toString() || null,
      roleLabel: user.adminRoleId
        ? roleMap.get(user.adminRoleId.toString()) || 'Unknown role'
        : 'Super Admin',
      joined: formatJoined(user.createdAt),
    }))

    return res.json({ data })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to load admin users.' })
  }
}

export const createAdminUser = async (req, res) => {
  try {
    const { fullName, email, password, adminRoleId } = req.body

    if (!fullName?.trim() || !email?.trim() || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required.' })
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters.' })
    }

    const existing = await User.findOne({ email: email.toLowerCase().trim() })
    if (existing) {
      return res.status(400).json({ message: 'An account with this email already exists.' })
    }

    const roleId = adminRoleId || null

    if (req.user.adminRoleId && !roleId) {
      return res.status(403).json({ message: 'Only super admins can create super admin accounts.' })
    }

    let roleName = null
    if (roleId) {
      const role = await Role.findById(roleId)
      if (!role) {
        return res.status(400).json({ message: 'Selected role not found.' })
      }
      roleName = role.name
    }

    const user = await User.create({
      fullName: fullName.trim(),
      email: email.toLowerCase().trim(),
      password,
      role: 'admin',
      status: 'approved',
      adminRoleId: roleId,
    })

    return res.status(201).json({
      message: 'Admin user created.',
      user: {
        id: user._id.toString(),
        name: user.fullName,
        email: user.email,
        adminRoleId: user.adminRoleId?.toString() || null,
        roleLabel: roleName || 'Super Admin',
        joined: formatJoined(user.createdAt),
      },
    })
  } catch (error) {
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors || {}).map((item) => ({
        field: item.path,
        message: item.message,
      }))
      return res.status(400).json({
        message: errors[0]?.message || 'Validation failed.',
        errors,
      })
    }

    if (error.code === 11000) {
      return res.status(400).json({ message: 'An account with this email already exists.' })
    }

    return res.status(500).json({ message: error.message || 'Failed to create admin user.' })
  }
}

export const rejectAccount = async (req, res) => {
  try {
    const { id } = req.params
    const user = await User.findById(id)

    if (!user || !['supplier', 'user'].includes(user.role)) {
      return res.status(404).json({ message: 'Account not found.' })
    }

    user.status = 'rejected'
    await user.save()

    await BusinessProfile.findOneAndUpdate(
      { user: user._id },
      { status: 'rejected' },
      { new: true },
    )

    return res.json({
      message: 'Account rejected.',
      user: user.toSafeObject(),
    })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to reject account.' })
  }
}

export const changeAdminPassword = async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current password and new password are required.' })
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'New password must be at least 6 characters.' })
    }

    if (newPassword !== confirmPassword) {
      return res.status(400).json({ message: 'New passwords do not match.' })
    }

    const user = await User.findById(req.user._id).select('+password')
    if (!user) {
      return res.status(404).json({ message: 'User not found.' })
    }

    const isMatch = await user.matchPassword(currentPassword)
    if (!isMatch) {
      return res.status(400).json({ message: 'Current password is incorrect.' })
    }

    user.password = newPassword
    await user.save()

    let roleTitle = 'Super Admin'
    if (user.adminRoleId) {
      const role = await Role.findById(user.adminRoleId)
      roleTitle = role?.name || 'Sub-Admin'
    }

    // Create notification for Super Admin
    await AdminNotification.create({
      type: 'password_change',
      title: 'Password Changed',
      message: `${user.fullName} (${user.email} · ${roleTitle}) changed their account password.`,
      userId: user._id,
      metadata: {
        email: user.email,
        fullName: user.fullName,
        role: roleTitle,
        date: new Date().toISOString(),
      },
    })

    return res.json({ message: 'Password updated successfully.' })
  } catch (error) {
    console.error('Change password error:', error)
    return res.status(500).json({ message: error.message || 'Failed to update password.' })
  }
}

export const listAdminNotifications = async (req, res) => {
  try {
    const notifications = await AdminNotification.find()
      .sort({ createdAt: -1 })
      .limit(50)

    const unreadCount = notifications.filter(
      (n) => !n.readBy.some((uid) => uid.toString() === req.user._id.toString()),
    ).length

    const data = notifications.map((n) => ({
      id: n._id.toString(),
      type: n.type,
      title: n.title,
      message: n.message,
      metadata: n.metadata,
      isRead: n.readBy.some((uid) => uid.toString() === req.user._id.toString()),
      createdAt: n.createdAt,
    }))

    return res.json({ data, unreadCount })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to load notifications.' })
  }
}

export const markAdminNotificationRead = async (req, res) => {
  try {
    const { id } = req.params
    await AdminNotification.findByIdAndUpdate(id, {
      $addToSet: { readBy: req.user._id },
    })
    return res.json({ message: 'Notification marked as read.' })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to update notification.' })
  }
}

export const markAllAdminNotificationsRead = async (req, res) => {
  try {
    await AdminNotification.updateMany(
      {},
      { $addToSet: { readBy: req.user._id } },
    )
    return res.json({ message: 'All notifications marked as read.' })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to mark all as read.' })
  }
}

export const listAllAccounts = async (req, res) => {
  try {
    const { role = 'all', status = 'all', search = '', page = 1, limit = 50 } = req.query

    // Case 1: Specific Supplier or Customer query from their dedicated pages / reporting widgets
    if (role === 'supplier' || role === 'user') {
      const query = { role }

      if (status && status !== 'all') {
        query.status = status
      }

      if (search?.trim()) {
        const regex = new RegExp(search.trim(), 'i')
        const matchingProfiles = await BusinessProfile.find({
          $or: [
            { businessName: regex },
            { city: regex },
            { country: regex },
            { businessPhone: regex },
          ],
        }).select('user')

        const profileUserIds = matchingProfiles.map((p) => p.user)

        query.$or = [
          { fullName: regex },
          { email: regex },
          { _id: { $in: profileUserIds } },
        ]
      }

      const pageNum = Math.max(1, parseInt(page, 10) || 1)
      const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 50))
      const skip = (pageNum - 1) * limitNum

      const [users, total] = await Promise.all([
        User.find(query).sort({ createdAt: -1 }).skip(skip).limit(limitNum),
        User.countDocuments(query),
      ])

      const userIds = users.map((u) => u._id)
      const [profiles, orderCounts, reviewStats] = await Promise.all([
        BusinessProfile.find({ user: { $in: userIds } }),
        Order.aggregate([
          {
            $match: {
              $or: [{ supplier: { $in: userIds } }, { user: { $in: userIds } }],
              status: { $ne: 'cancelled' },
            },
          },
          {
            $group: {
              _id: {
                $cond: [{ $in: ['$supplier', userIds] }, '$supplier', '$user'],
              },
              count: { $sum: 1 },
              totalSpent: { $sum: '$total' },
              totalEarnings: { $sum: { $subtract: ['$total', '$commission'] } },
            },
          },
        ]),
        Review.aggregate([
          { $match: { supplier: { $in: userIds } } },
          {
            $group: {
              _id: '$supplier',
              count: { $sum: 1 },
              totalProductRating: { $sum: '$productRating' },
              totalDeliveryRating: { $sum: '$deliveryRating' },
              onTimeCount: { $sum: { $cond: ['$deliveredOnTime', 1, 0] } },
              badRatingsCount: {
                $sum: {
                  $cond: [
                    {
                      $or: [
                        { $lte: ['$productRating', 2] },
                        { $lte: ['$deliveryRating', 2] },
                        { $eq: ['$deliveredOnTime', false] },
                      ],
                    },
                    1,
                    0,
                  ],
                },
              },
            },
          },
        ]),
      ])

      const profileMap = new Map(profiles.map((p) => [p.user.toString(), p]))
      const orderMap = new Map(orderCounts.map((o) => [o._id.toString(), o]))
      const reviewMap = new Map(reviewStats.map((r) => [r._id.toString(), r]))

      const [totalSuppliers, totalUsers, totalApproved, totalSuspended, totalPending, totalWmsSuppliers, totalWithWarnings] = await Promise.all([
        User.countDocuments({ role: 'supplier' }),
        User.countDocuments({ role: 'user' }),
        User.countDocuments({ role: { $in: ['supplier', 'user'] }, status: 'approved' }),
        User.countDocuments({ role: { $in: ['supplier', 'user'] }, status: 'suspended' }),
        User.countDocuments({ role: { $in: ['supplier', 'user'] }, status: { $in: ['pending_approval', 'pending_details'] } }),
        User.countDocuments({
          role: 'supplier',
          $or: [
            { isWmsRegistered: true },
            { wmsClientId: { $exists: true, $ne: '' } },
            { wmsSupplierId: { $exists: true, $ne: null } },
            { wmsToken: { $exists: true, $ne: '' } },
          ],
        }),
        User.countDocuments({ role: 'supplier', warningsCount: { $gt: 0 } }),
      ])

      const totalMarketplaceSuppliers = Math.max(0, totalSuppliers - totalWmsSuppliers)

      const data = users.map((user) => {
        const profile = profileMap.get(user._id.toString())
        const stats = orderMap.get(user._id.toString())
        const rev = reviewMap.get(user._id.toString())

        const ordersCount = stats?.count || 0
        const revenue = user.role === 'supplier' ? (stats?.totalEarnings || 0) : (stats?.totalSpent || 0)
        const isWms = Boolean(
          user.isWmsRegistered ||
          user.wmsClientId ||
          user.wmsToken ||
          user.wmsSupplierId
        )

        const reviewsCount = rev?.count || 0
        const avgRating = reviewsCount > 0 ? Number((rev.totalProductRating / reviewsCount).toFixed(1)) : 0
        const avgDelivery = reviewsCount > 0 ? Number((rev.totalDeliveryRating / reviewsCount).toFixed(1)) : 0
        const onTimePct = reviewsCount > 0 ? Math.round((rev.onTimeCount / reviewsCount) * 100) : 100
        const badCount = rev?.badRatingsCount || 0
        const warningsCount = user.warningsCount ?? (user.warnings?.length || 0)
        const isLowPerformance = (reviewsCount >= 1 && (avgRating < 3.0 || onTimePct < 70)) || badCount >= 1

        return {
          id: user._id.toString(),
          fullName: user.fullName,
          email: user.email,
          role: user.role,
          status: user.status,
          walletBalance: user.walletBalance ?? 0,
          joined: formatJoined(user.createdAt),
          createdAt: user.createdAt,
          ordersCount,
          revenue: Math.round(revenue * 100) / 100,
          revenueLabel: `$${revenue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
          isWmsRegistered: isWms,
          wmsClientId: user.wmsClientId || '',
          wmsSupplierId: user.wmsSupplierId || null,
          wmsStatus: user.wmsStatus || '',
          supplierType: isWms ? 'wms' : 'marketplace_only',
          originLabel: isWms ? 'WMS Warehouse (3PL)' : 'Marketplace Only',
          ratings: {
            reviewsCount,
            averageRating: avgRating,
            deliveryRatingAverage: avgDelivery,
            onTimeDeliveryPercent: onTimePct,
            badRatingsCount: badCount,
            isLowPerformance,
          },
          warningsCount,
          warnings: user.warnings || [],
          suspensionReason: user.suspensionReason || '',
          suspendedAt: user.suspendedAt || null,
          canSuspend: warningsCount >= 3 || user.status === 'suspended',
          businessProfile: profile
            ? {
                businessName: profile.businessName || '',
                businessCategory: profile.businessCategory || '',
                businessPhone: profile.businessPhone || '',
                city: profile.city || '',
                country: profile.country || '',
                location: [profile.city, profile.country].filter(Boolean).join(', ') || '—',
                paymentProvider: profile.paymentProvider || 'Not set',
                payoutSchedule: profile.payoutSchedule || 'Weekly',
              }
            : null,
        }
      })

      return res.json({
        data,
        stats: {
          totalAccounts: totalSuppliers + totalUsers,
          totalSuppliers,
          totalWithWarnings,
          totalUsers,
          totalApproved,
          totalSuspended,
          totalPending,
          totalWmsSuppliers,
          totalMarketplaceSuppliers,
        },
        pagination: {
          page: pageNum,
          limit: limitNum,
          total,
          totalPages: Math.ceil(total / limitNum) || 1,
        },
      })
    }

    // Case 2: Settings -> Accounts Management
    // Exclude Suppliers and Users! Display internal Staff, Administrators, Sub-admins and Managers.
    const query = { role: 'admin' }

    if (role === 'super_admin') {
      query.adminRoleId = null
    } else if (role === 'sub_admin') {
      query.adminRoleId = { $ne: null }
    }

    if (status && status !== 'all') {
      query.status = status
    }

    if (search?.trim()) {
      const regex = new RegExp(search.trim(), 'i')
      const matchingRoles = await Role.find({ name: regex }).select('_id')
      const matchingRoleIds = matchingRoles.map((r) => r._id)

      query.$or = [
        { fullName: regex },
        { email: regex },
        { adminRoleId: { $in: matchingRoleIds } },
      ]
    }

    const pageNum = Math.max(1, parseInt(page, 10) || 1)
    const limitNum = Math.min(100, Math.max(1, parseInt(limit, 10) || 50))
    const skip = (pageNum - 1) * limitNum

    const [users, total, allRoles, totalStaff, totalSuperAdmins, totalSubAdmins, totalApproved, totalSuspended] = await Promise.all([
      User.find(query).sort({ createdAt: -1 }).skip(skip).limit(limitNum),
      User.countDocuments(query),
      Role.find({}),
      User.countDocuments({ role: 'admin' }),
      User.countDocuments({ role: 'admin', adminRoleId: null }),
      User.countDocuments({ role: 'admin', adminRoleId: { $ne: null } }),
      User.countDocuments({ role: 'admin', status: 'approved' }),
      User.countDocuments({ role: 'admin', status: 'suspended' }),
    ])

    const roleMap = new Map(allRoles.map((r) => [r._id.toString(), r]))

    const data = users.map((user) => {
      const assignedRole = user.adminRoleId ? roleMap.get(user.adminRoleId.toString()) : null
      const isSuper = !user.adminRoleId
      const roleLabel = isSuper ? 'Super Admin' : (assignedRole?.name || 'Sub-Admin')
      const permissionsCount = isSuper ? null : (assignedRole?.permissions?.length ?? 0)

      return {
        id: user._id.toString(),
        fullName: user.fullName,
        email: user.email,
        role: 'admin',
        adminRoleId: user.adminRoleId?.toString() || null,
        roleLabel,
        roleDescription: isSuper
          ? 'Full root access with all administrative privileges'
          : (assignedRole?.description || 'Custom role permissions'),
        permissionsCount,
        status: user.status || 'approved',
        isSuperAdmin: isSuper,
        joined: formatJoined(user.createdAt),
        createdAt: user.createdAt,
      }
    })

    return res.json({
      data,
      stats: {
        totalAccounts: totalStaff,
        totalStaff,
        totalSuperAdmins,
        totalSubAdmins,
        totalApproved,
        totalSuspended,
      },
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum) || 1,
      },
    })
  } catch (error) {
    console.error('List accounts error:', error)
    return res.status(500).json({ message: error.message || 'Failed to list accounts.' })
  }
}

export const createAccount = async (req, res) => {
  try {
    const {
      fullName,
      email,
      password,
      role = 'admin',
      status = 'approved',
      adminRoleId,
      businessName,
      businessCategory,
      businessPhone,
      city,
      country,
      walletBalance = 0,
    } = req.body

    if (!fullName?.trim() || !email?.trim() || !password) {
      return res.status(400).json({ message: 'Full name, email, and password are required.' })
    }

    if (!['supplier', 'user', 'admin', 'staff'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role specified.' })
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters.' })
    }

    const existing = await User.findOne({ email: email.toLowerCase().trim() })
    if (existing) {
      return res.status(400).json({ message: 'An account with this email already exists.' })
    }

    const allowedStatuses = ['approved', 'pending_approval', 'pending_details', 'suspended', 'rejected']
    const finalStatus = allowedStatuses.includes(status) ? status : 'approved'

    // Admin / Staff creation
    if (role === 'admin' || role === 'staff') {
      const roleId = adminRoleId && adminRoleId !== 'super_admin' ? adminRoleId : null

      if (req.user?.adminRoleId && !roleId) {
        return res.status(403).json({ message: 'Only super administrators can create super admin accounts.' })
      }

      let roleName = null
      if (roleId) {
        const roleDoc = await Role.findById(roleId)
        if (!roleDoc) {
          return res.status(400).json({ message: 'Selected role not found.' })
        }
        roleName = roleDoc.name
      }

      const user = await User.create({
        fullName: fullName.trim(),
        email: email.toLowerCase().trim(),
        password,
        role: 'admin',
        status: finalStatus,
        adminRoleId: roleId,
      })

      return res.status(201).json({
        message: 'Staff account created successfully.',
        user: {
          id: user._id.toString(),
          fullName: user.fullName,
          email: user.email,
          role: 'admin',
          adminRoleId: user.adminRoleId?.toString() || null,
          roleLabel: roleName || 'Super Admin',
          status: user.status,
          joined: formatJoined(user.createdAt),
        },
      })
    }

    // Supplier / User creation
    const isWms = Boolean(req.body.isWmsRegistered || req.body.wmsClientId)
    const user = await User.create({
      fullName: fullName.trim(),
      email: email.toLowerCase().trim(),
      password,
      role,
      status: finalStatus,
      walletBalance: Math.max(0, Number(walletBalance) || 0),
      isWmsRegistered: isWms,
      wmsClientId: isWms ? String(req.body.wmsClientId || '').trim() : '',
      wmsStatus: isWms ? 'approved' : '',
    })

    await BusinessProfile.create({
      user: user._id,
      profileType: role,
      businessName: businessName?.trim() || fullName.trim(),
      businessCategory: businessCategory?.trim() || '',
      businessPhone: businessPhone?.trim() || '',
      businessEmail: email.toLowerCase().trim(),
      city: city?.trim() || '',
      country: country?.trim() || '',
      status: finalStatus === 'approved' ? 'approved' : 'pending',
    })

    return res.status(201).json({
      message: `${role === 'supplier' ? 'Supplier' : 'Customer user'} created successfully.`,
      user: user.toSafeObject(),
    })
  } catch (error) {
    console.error('Create account error:', error)
    if (error.code === 11000) {
      return res.status(400).json({ message: 'An account with this email already exists.' })
    }
    return res.status(500).json({ message: error.message || 'Failed to create account.' })
  }
}

export const updateAccount = async (req, res) => {
  try {
    const { id } = req.params
    const {
      fullName,
      email,
      role,
      status,
      adminRoleId,
      businessName,
      businessCategory,
      businessPhone,
      city,
      country,
      walletBalance,
      password,
    } = req.body

    const user = await User.findById(id).select('+password')
    if (!user) {
      return res.status(404).json({ message: 'Account not found.' })
    }

    if (email?.trim() && email.toLowerCase().trim() !== user.email) {
      const conflict = await User.findOne({ email: email.toLowerCase().trim(), _id: { $ne: user._id } })
      if (conflict) {
        return res.status(400).json({ message: 'Email address is already in use by another account.' })
      }
      user.email = email.toLowerCase().trim()
    }

    if (fullName?.trim()) user.fullName = fullName.trim()

    if (password) {
      if (password.length < 6) {
        return res.status(400).json({ message: 'Password must be at least 6 characters.' })
      }
      user.password = password
    }

    // Handle Staff / Admin account update
    if (user.role === 'admin') {
      if (status && ['approved', 'suspended'].includes(status)) {
        if (user._id.toString() === req.user._id.toString() && status === 'suspended') {
          return res.status(400).json({ message: 'You cannot suspend your own account.' })
        }
        user.status = status
      }

      if (adminRoleId !== undefined) {
        const isSuper = adminRoleId === 'super_admin' || adminRoleId === '' || adminRoleId === null
        if (isSuper) {
          if (req.user?.adminRoleId) {
            return res.status(403).json({ message: 'Only super administrators can assign Super Admin role.' })
          }
          user.adminRoleId = null
        } else {
          const roleDoc = await Role.findById(adminRoleId)
          if (!roleDoc) {
            return res.status(400).json({ message: 'Selected role not found.' })
          }
          user.adminRoleId = roleDoc._id
        }
      }

      await user.save()

      let roleLabel = 'Super Admin'
      if (user.adminRoleId) {
        const roleDoc = await Role.findById(user.adminRoleId)
        roleLabel = roleDoc?.name || 'Sub-Admin'
      }

      return res.json({
        message: 'Staff account updated successfully.',
        user: {
          id: user._id.toString(),
          fullName: user.fullName,
          email: user.email,
          role: 'admin',
          status: user.status,
          adminRoleId: user.adminRoleId?.toString() || null,
          roleLabel,
          joined: formatJoined(user.createdAt),
        },
      })
    }

    // Regular User / Supplier update
    if (role && ['supplier', 'user'].includes(role)) {
      user.role = role
    }

    if (status && ['approved', 'pending_approval', 'pending_details', 'suspended', 'rejected'].includes(status)) {
      user.status = status
    }

    if (walletBalance !== undefined && !isNaN(Number(walletBalance))) {
      user.walletBalance = Math.max(0, Number(walletBalance))
    }

    if (typeof req.body.isWmsRegistered === 'boolean') {
      user.isWmsRegistered = req.body.isWmsRegistered
    }
    if (req.body.wmsClientId !== undefined) {
      user.wmsClientId = String(req.body.wmsClientId || '').trim()
    }
    if (req.body.wmsSupplierId !== undefined) {
      user.wmsSupplierId = req.body.wmsSupplierId ? Number(req.body.wmsSupplierId) : null
    }
    if (req.body.wmsStatus !== undefined) {
      user.wmsStatus = String(req.body.wmsStatus || '').trim()
    }

    await user.save()

    const profileData = {
      profileType: user.role,
      status: user.status === 'approved' ? 'approved' : user.status === 'rejected' ? 'rejected' : 'pending',
    }

    if (businessName !== undefined) profileData.businessName = businessName.trim()
    if (businessCategory !== undefined) profileData.businessCategory = businessCategory.trim()
    if (businessPhone !== undefined) profileData.businessPhone = businessPhone.trim()
    if (city !== undefined) profileData.city = city.trim()
    if (country !== undefined) profileData.country = country.trim()
    if (user.email) profileData.businessEmail = user.email

    const profile = await BusinessProfile.findOneAndUpdate(
      { user: user._id },
      { $set: profileData },
      { new: true, upsert: true },
    )

    return res.json({
      message: 'Account updated successfully.',
      user: {
        ...user.toSafeObject(),
        businessProfile: profile,
      },
    })
  } catch (error) {
    console.error('Update account error:', error)
    return res.status(500).json({ message: error.message || 'Failed to update account.' })
  }
}

export const deleteAccount = async (req, res) => {
  try {
    const { id } = req.params

    const user = await User.findById(id)
    if (!user) {
      return res.status(404).json({ message: 'Account not found.' })
    }

    if (user.role === 'admin') {
      if (user._id.toString() === req.user._id.toString()) {
        return res.status(400).json({ message: 'You cannot delete your own account.' })
      }

      if (!user.adminRoleId) {
        const superAdminCount = await User.countDocuments({ role: 'admin', adminRoleId: null })
        if (superAdminCount <= 1) {
          return res.status(400).json({ message: 'Cannot delete the only Super Administrator account.' })
        }
      }

      await User.findByIdAndDelete(user._id)
      return res.json({ message: 'Staff account deleted successfully.' })
    }

    await BusinessProfile.deleteMany({ user: user._id })
    await User.findByIdAndDelete(user._id)

    return res.json({ message: `${user.role === 'supplier' ? 'Supplier' : 'User'} account deleted successfully.` })
  } catch (error) {
    console.error('Delete account error:', error)
    return res.status(500).json({ message: error.message || 'Failed to delete account.' })
  }
}

export const impersonateAccount = async (req, res) => {
  try {
    const { id } = req.params

    const targetUser = await User.findById(id)
    if (!targetUser) {
      return res.status(404).json({ message: 'Target user not found.' })
    }

    if (targetUser.role === 'admin') {
      return res.status(403).json({ message: 'Administrator accounts cannot be impersonated.' })
    }

    const adminToken = readAuthToken(req) || signToken(req.user._id)
    setImpersonatorCookie(res, adminToken)

    const targetToken = signToken(targetUser._id)
    setAuthCookie(res, targetToken)

    const redirectUrl =
      targetUser.role === 'supplier'
        ? targetUser.status === 'approved'
          ? '/supplier/dashboard'
          : '/supplier/business/details'
        : targetUser.status === 'approved'
          ? '/user/dashboard'
          : '/user/business/detail'

    return res.json({
      message: `Now viewing as ${targetUser.fullName} (${targetUser.role}).`,
      user: targetUser.toSafeObject(),
      redirectUrl,
    })
  } catch (error) {
    console.error('Impersonation error:', error)
    return res.status(500).json({ message: error.message || 'Failed to start impersonation.' })
  }
}

export const listCountries = async (_req, res) => {
  try {
    const countries = await Country.find().sort({ name: 1 })
    return res.json({ data: countries.map((c) => c.toSafeObject()) })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to list countries.' })
  }
}

export const createCountry = async (req, res) => {
  try {
    const { name } = req.body
    if (!name?.trim()) {
      return res.status(400).json({ message: 'Country name is required.' })
    }

    const existing = await Country.findOne({ name: new RegExp(`^${name.trim()}$`, 'i') })
    if (existing) {
      return res.status(400).json({ message: 'Country already exists.' })
    }

    const country = await Country.create({ name: name.trim() })
    return res.status(201).json({ message: 'Country created successfully.', data: country.toSafeObject() })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to create country.' })
  }
}

export const deleteCountry = async (req, res) => {
  try {
    const { id } = req.params
    await Country.findByIdAndDelete(id)
    return res.json({ message: 'Country deleted successfully.' })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to delete country.' })
  }
}

export const listLocations = async (_req, res) => {
  try {
    const locations = await Location.find().sort({ name: 1 })
    return res.json({ data: locations.map((l) => l.toSafeObject()) })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to list locations.' })
  }
}

export const createLocation = async (req, res) => {
  try {
    const { name, description = '' } = req.body
    if (!name?.trim()) {
      return res.status(400).json({ message: 'Location name is required.' })
    }

    const existing = await Location.findOne({ name: new RegExp(`^${name.trim()}$`, 'i') })
    if (existing) {
      return res.status(400).json({ message: 'Location already exists.' })
    }

    const location = await Location.create({ name: name.trim(), description: description.trim() })
    return res.status(201).json({ message: 'Location created successfully.', data: location.toSafeObject() })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to create location.' })
  }
}

export const deleteLocation = async (req, res) => {
  try {
    const { id } = req.params
    await Location.findByIdAndDelete(id)
    return res.json({ message: 'Location deleted successfully.' })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to delete location.' })
  }
}

/**
 * Issue official performance warning to supplier due to bad ratings / delivery delays
 * POST /api/admin/suppliers/:id/warn
 */
export const warnSupplierAccount = async (req, res) => {
  try {
    const { id } = req.params
    const { reason, details } = req.body

    const supplier = await User.findById(id)
    if (!supplier || supplier.role !== 'supplier') {
      return res.status(404).json({ message: 'Supplier account not found.' })
    }

    // Calculate current performance from Review collection
    const reviews = await Review.find({ supplier: supplier._id })
    const count = reviews.length
    let sumProduct = 0
    let onTimeCount = 0
    reviews.forEach((r) => {
      sumProduct += r.productRating || 0
      if (r.deliveredOnTime) onTimeCount += 1
    })
    const avgRating = count > 0 ? Number((sumProduct / count).toFixed(1)) : 0
    const onTimePct = count > 0 ? Math.round((onTimeCount / count) * 100) : 100

    const nextWarningNumber = (supplier.warningsCount || 0) + 1
    const warningRecord = {
      warningNumber: nextWarningNumber,
      reason: reason?.trim() || 'Poor Product Quality & Bad Customer Ratings',
      details: details?.trim() || '',
      averageRating: avgRating,
      onTimeDeliveryPercent: onTimePct,
      warnedAt: new Date(),
      warnedBy: req.user?._id,
    }

    supplier.warningsCount = nextWarningNumber
    if (!supplier.warnings) supplier.warnings = []
    supplier.warnings.push(warningRecord)
    await supplier.save()

    // Create In-App Notification
    try {
      await createNotification({
        userId: supplier._id,
        title: `⚠️ Performance Warning #${nextWarningNumber}`,
        message: `Admin has issued official warning #${nextWarningNumber} (Max: 3): ${warningRecord.reason}`,
        type: 'account',
      })
    } catch {}

    // Send Official Warning Email
    try {
      await sendSupplierWarningEmail(supplier.email, {
        supplierName: supplier.fullName,
        warningNumber: nextWarningNumber,
        maxWarnings: 3,
        reason: warningRecord.reason,
        details: warningRecord.details,
        averageRating: avgRating,
        onTimeDeliveryPercent: onTimePct,
      })
    } catch (mailErr) {
      console.error('Failed to dispatch warning email:', mailErr)
    }

    return res.json({
      success: true,
      message: `Warning #${nextWarningNumber} of 3 issued successfully to ${supplier.fullName}. Warning email has been sent.`,
      warningsCount: supplier.warningsCount,
      isLimitReached: supplier.warningsCount >= 3,
      warning: warningRecord,
    })
  } catch (error) {
    console.error('Warn supplier error:', error)
    return res.status(500).json({ message: error.message || 'Failed to issue warning.' })
  }
}

/**
 * Suspend supplier account (after 3 warnings or admin enforcement)
 * POST /api/admin/suppliers/:id/suspend
 */
export const suspendSupplierAccount = async (req, res) => {
  try {
    const { id } = req.params
    const { reason, forceOverride = false } = req.body

    const supplier = await User.findById(id)
    if (!supplier || supplier.role !== 'supplier') {
      return res.status(404).json({ message: 'Supplier account not found.' })
    }

    // Policy check: "3 bar sy ziyada warn k bad usse suspende kr sake"
    if ((supplier.warningsCount || 0) < 3 && !forceOverride) {
      return res.status(400).json({
        message: `Supplier has received ${supplier.warningsCount || 0} warning(s). Standard policy requires 3 warnings before suspension.`,
        requireOverride: true,
        currentWarnings: supplier.warningsCount || 0,
      })
    }

    // Performance snapshot for suspension record
    const reviews = await Review.find({ supplier: supplier._id })
    const count = reviews.length
    let sumProduct = 0
    let onTimeCount = 0
    reviews.forEach((r) => {
      sumProduct += r.productRating || 0
      if (r.deliveredOnTime) onTimeCount += 1
    })
    const avgRating = count > 0 ? Number((sumProduct / count).toFixed(1)) : 0
    const onTimePct = count > 0 ? Math.round((onTimeCount / count) * 100) : 100

    supplier.status = 'suspended'
    supplier.suspensionReason =
      reason?.trim() ||
      `Account suspended due to repeated low customer ratings, delivery SLA breach, and exceeding the threshold of 3 performance warnings.`
    supplier.suspendedAt = new Date()
    await supplier.save()

    // Deactivate active products from marketplace
    await Product.updateMany(
      { supplier: supplier._id, status: 'active' },
      { status: 'inactive' },
    )

    // In-App Notification
    try {
      await createNotification({
        userId: supplier._id,
        title: '🚫 Supplier Account Suspended',
        message: supplier.suspensionReason,
        type: 'account',
      })
    } catch {}

    // Send Suspension Email
    try {
      await sendSupplierSuspensionEmail(supplier.email, {
        supplierName: supplier.fullName,
        reason: supplier.suspensionReason,
        totalWarnings: supplier.warningsCount || 3,
        averageRating: avgRating,
        onTimeDeliveryPercent: onTimePct,
      })
    } catch (mailErr) {
      console.error('Failed to dispatch suspension email:', mailErr)
    }

    return res.json({
      success: true,
      message: `Supplier ${supplier.fullName} has been suspended. Listings deactivated and formal suspension email dispatched.`,
      supplier: supplier.toSafeObject(),
    })
  } catch (error) {
    console.error('Suspend supplier error:', error)
    return res.status(500).json({ message: error.message || 'Failed to suspend supplier.' })
  }
}

/**
 * Reinstate suspended supplier account
 * POST /api/admin/suppliers/:id/reinstate
 */
export const reinstateSupplierAccount = async (req, res) => {
  try {
    const { id } = req.params
    const supplier = await User.findById(id)
    if (!supplier || supplier.role !== 'supplier') {
      return res.status(404).json({ message: 'Supplier account not found.' })
    }

    supplier.status = 'approved'
    supplier.suspensionReason = ''
    supplier.suspendedAt = null
    await supplier.save()

    try {
      await createNotification({
        userId: supplier._id,
        title: '✅ Supplier Account Reinstated',
        message: 'Your supplier account has been reinstated. You may now reactivate your product listings in the portal.',
        type: 'account',
      })
    } catch {}

    return res.json({
      success: true,
      message: `Supplier ${supplier.fullName} has been reinstated successfully.`,
      supplier: supplier.toSafeObject(),
    })
  } catch (error) {
    return res.status(500).json({ message: error.message || 'Failed to reinstate supplier.' })
  }
}




