import { useCallback, useEffect, useState } from 'react'
import { Ban, Building2, Check, ExternalLink, Plus, Printer, RefreshCw, Star, Tag, Truck, Warehouse, X } from 'lucide-react'
import Badge from '../ui/Badge.jsx'
import Button from '../ui/Button.jsx'
import TrackingModal from './TrackingModal.jsx'
import CourierHandoverModal from './CourierHandoverModal.jsx'
import OrderReviewModal from './OrderReviewModal.jsx'
import UserCancelOrderModal from './UserCancelOrderModal.jsx'
import UserUpdateTrackingModal from './UserUpdateTrackingModal.jsx'
import ShippingAirwayBillModal from './ShippingAirwayBillModal.jsx'
import { getErrorMessage, orderApi, mediaUrl } from '../../lib/api.js'
import { formatSupplierId, formatUserId } from '../../lib/idFormatters.js'
import { getCourierExternalTrackingUrl } from '../../lib/courierHelpers.js'
import { formatShippingAddress, hasShippingAddress, ORDER_STATUS_OPTIONS } from '../../lib/orderHelpers.js'

function statusTone(status) {
  const value = String(status || '').toLowerCase()
  if (value === 'cancelled') return 'danger'
  if (value === 'placed') return 'success'
  if (value.includes('process') || value === 'pending') return 'warning'
  return 'neutral'
}

function Field({ label, children }) {
  return (
    <div>
      <dt className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</dt>
      <dd className="mt-1 whitespace-pre-line text-sm font-medium text-slate-700">{children}</dd>
    </div>
  )
}

/**
 * Side drawer showing full order details for admin / user / supplier.
 * Loads live data via orderApi.lookup. Optional status update for admin/supplier.
 */
function OrderDetailDrawer({
  orderId,
  open,
  onClose,
  onUpdated,
  showStatusUpdate = false,
  title = 'Order Details',
}) {
  const [order, setOrder] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [status, setStatus] = useState('')
  const [warehouseLoc, setWarehouseLoc] = useState('')
  const [showThermalLabel, setShowThermalLabel] = useState(false)
  const [saving, setSaving] = useState(false)
  const [trackingLive, setTrackingLive] = useState(false)
  const [liveTrackSuccess, setLiveTrackSuccess] = useState('')
  const [trackingModalOpen, setTrackingModalOpen] = useState(false)
  const [courierModalOpen, setCourierModalOpen] = useState(false)
  const [reviewModalOpen, setReviewModalOpen] = useState(false)
  const [cancelModalOpen, setCancelModalOpen] = useState(false)
  const [updateTrackingOpen, setUpdateTrackingOpen] = useState(false)
  const [showLabelModal, setShowLabelModal] = useState(false)

  const loadOrder = useCallback(async () => {
    if (!orderId) return
    setLoading(true)
    setError('')
    try {
      const data = await orderApi.lookup(orderId)
      const next = data.order || data
      setOrder(next)
      setStatus(next.status || 'placed')
      setWarehouseLoc(next.warehouseLocation || 'supplier_warehouse')
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to load order.'))
      setOrder(null)
    } finally {
      setLoading(false)
    }
  }, [orderId])

  useEffect(() => {
    if (open && orderId) {
      loadOrder()
    }
    if (!open) {
      setOrder(null)
      setError('')
      setStatus('')
      setWarehouseLoc('')
    }
  }, [open, orderId, loadOrder])

  const handleStatusUpdate = async () => {
    if (!order?.id || !status) return
    setSaving(true)
    setError('')
    try {
      let next
      if (status !== order.status) {
        const data = await orderApi.updateStatus(order.id, status)
        next = data.order || data
      }
      if (warehouseLoc && warehouseLoc !== order.warehouseLocation) {
        const trackData = await orderApi.updateTracking(order.id, {
          warehouseLocation: warehouseLoc,
          trackingStatus:
            warehouseLoc === 'delivered'
              ? 'delivered'
              : warehouseLoc === 'in_transit'
                ? 'in_transit'
                : status === 'in_process'
                  ? 'processing'
                  : 'placed',
          note: `Location updated to ${warehouseLoc === 'wms_hub' ? 'WMS Central Hub' : warehouseLoc === 'supplier_warehouse' ? 'Supplier Warehouse' : warehouseLoc}`,
        })
        next = trackData.order || trackData
      }
      if (next) {
        setOrder(next)
        setStatus(next.status || status)
        setWarehouseLoc(next.warehouseLocation || warehouseLoc)
        onUpdated?.(next)
      }
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to update order status or location.'))
    } finally {
      setSaving(false)
    }
  }

  const [pushingWms, setPushingWms] = useState(false)

  const handlePushWms = async () => {
    if (!order?.id) return
    setPushingWms(true)
    setError('')
    try {
      const res = await orderApi.pushWms(order.id)
      if (res?.order) {
        setOrder(res.order)
        onUpdated?.(res.order)
      }
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to push order to WMS.'))
    } finally {
      setPushingWms(false)
    }
  }

  const handleLiveTrack = async () => {
    if (!order?.id) return
    setTrackingLive(true)
    setError('')
    setLiveTrackSuccess('')
    try {
      const res = await orderApi.trackWms(order.id)
      if (res?.order) {
        setOrder(res.order)
        setStatus(res.order.status || status)
        setWarehouseLoc(res.order.warehouseLocation || warehouseLoc)
        onUpdated?.(res.order)
        setLiveTrackSuccess('Live WMS Tracking synced successfully!')
        setTimeout(() => setLiveTrackSuccess(''), 4500)
      }
    } catch (err) {
      setError(getErrorMessage(err, 'Failed to sync live tracking from WMS.'))
    } finally {
      setTrackingLive(false)
    }
  }

  if (!open) return null

  const shipping = order?.shippingAddress

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <button
        type="button"
        aria-label="Close order panel"
        className="absolute inset-0 bg-slate-900/30"
        onClick={onClose}
      />
      <aside className="relative flex h-full w-full max-w-lg flex-col bg-white shadow-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-slate-100 px-5 py-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{title}</p>
            <h2 className="mt-1 text-lg font-semibold text-slate-900">
              {order?.orderNo || (loading ? 'Loading…' : 'Order')}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-2 text-slate-400 hover:bg-slate-50 hover:text-slate-600"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {error && (
            <p className="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm text-rose-600">
              {error}
            </p>
          )}

          {loading && !order ? (
            <p className="text-sm text-slate-500">Loading order…</p>
          ) : order ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Badge tone={statusTone(order.status)}>{order.statusLabel || order.status}</Badge>
                  <span className="text-sm text-slate-500">{order.date}</span>
                </div>
                {order.orderLabelRef && (
                  <span className="rounded bg-slate-100 px-2 py-0.5 font-mono text-xs font-semibold text-slate-700">
                    Label: {order.orderLabelRef}
                  </span>
                )}
              </div>

              {/* Delivery Rating & Feedback Prompt Banner (If Delivered) */}
              {(() => {
                const isDelivered =
                  (order.trackingStatus || order.status || order.warehouseLocation || '').toLowerCase() === 'delivered'
                if (!isDelivered) return null

                if (order.isReviewed) {
                  return (
                    <div className="flex items-center gap-2 rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-xs text-emerald-800">
                      <Check className="h-4 w-4 text-emerald-600 shrink-0" />
                      <span>
                        <strong>Reviewed:</strong> You have submitted ratings &amp; review for this supplier and product.
                      </span>
                    </div>
                  )
                }

                return (
                  <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-300 bg-linear-to-r from-amber-50 to-orange-50 p-3 shadow-2xs">
                    <div className="flex items-center gap-2.5">
                      <Star className="h-5 w-5 fill-amber-500 text-amber-500 shrink-0" />
                      <div>
                        <h5 className="text-xs font-bold text-amber-900">Rate Supplier &amp; Product</h5>
                        <p className="text-[11px] text-amber-700">Order delivered! Please share your feedback on delivery speed and product quality.</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setReviewModalOpen(true)}
                      className="inline-flex items-center gap-1 rounded-lg bg-amber-500 px-3 py-1.5 text-xs font-bold text-white shadow-2xs hover:bg-amber-600 transition cursor-pointer"
                    >
                      <Star className="h-3.5 w-3.5 fill-white" /> Rate Now
                    </button>
                  </div>
                )
              })()}

              {/* Warehouse Custody Banner */}
              <div className="flex items-center justify-between rounded-xl border border-slate-200 bg-slate-50 p-3">
                <div className="flex items-center gap-2.5">
                  {order.warehouseLocation === 'wms_hub' ? (
                    <Warehouse className="h-5 w-5 text-amber-600" />
                  ) : (
                    <Building2 className="h-5 w-5 text-blue-600" />
                  )}
                  <div>
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">
                      Warehouse Custody
                    </span>
                    <span className="text-sm font-bold text-slate-900">
                      {order.warehouseLocationLabel ||
                        (order.warehouseLocation === 'wms_hub'
                          ? 'At WMS Central Hub'
                          : order.warehouseLocation === 'in_transit'
                            ? 'In Courier Transit'
                            : order.warehouseLocation === 'delivered'
                              ? 'Delivered to Customer'
                              : 'At Supplier Warehouse')}
                    </span>
                  </div>
                </div>
                <span
                  className={`rounded-full px-2.5 py-0.5 text-xs font-semibold shadow-xs ${order.warehouseLocation === 'wms_hub'
                    ? 'border border-amber-200 bg-amber-50 text-amber-800'
                    : 'border border-blue-200 bg-blue-50 text-blue-800'
                    }`}
                >
                  {order.warehouseLocation === 'wms_hub' ? 'WMS Fulfilled' : 'Supplier Direct'}
                </span>
              </div>

              {/* User ID & Supplier ID Info */}
              <dl className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
                  <dt className="text-[10px] font-bold uppercase tracking-wider text-slate-400">User / Buyer</dt>
                  <dd className="mt-1">
                    <span className="inline-block rounded bg-indigo-50 px-1.5 py-0.5 font-mono text-xs font-bold text-indigo-700">
                      {formatUserId(order.userDisplayId || order.userId)}
                    </span>
                    <p className="mt-1 text-sm font-semibold text-slate-800">{order.user}</p>
                    {order.userEmail ? <p className="text-xs text-slate-500">{order.userEmail}</p> : null}
                  </dd>
                </div>

                <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
                  <dt className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Supplier / Vendor</dt>
                  <dd className="mt-1">
                    <span className="inline-block rounded bg-amber-50 px-1.5 py-0.5 font-mono text-xs font-bold text-amber-800">
                      {formatSupplierId(order.supplierDisplayId || order.supplierId)}
                    </span>
                    <p className="mt-1 text-sm font-semibold text-slate-800">{order.supplier}</p>
                    {order.supplierEmail ? <p className="text-xs text-slate-500">{order.supplierEmail}</p> : null}
                  </dd>
                </div>
              </dl>

              {/* Product Specifications */}
              <div className="rounded-xl border border-slate-100 bg-slate-50 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">Product</p>
                <p className="mt-2 text-sm font-semibold text-slate-800">{order.product}</p>
                {order.productSku ? (
                  <p className="mt-0.5 font-mono text-xs font-semibold text-indigo-700">SKU: {order.productSku}</p>
                ) : null}
                <div className="mt-3 grid grid-cols-3 gap-3 text-sm">
                  <div>
                    <p className="text-xs text-slate-400">Qty</p>
                    <p className="font-medium text-slate-700">{order.quantity}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Unit</p>
                    <p className="font-medium text-slate-700">${Number(order.unitPrice || 0).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Total</p>
                    <p className="font-medium text-slate-700">${Number(order.total || 0).toFixed(2)}</p>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-3 text-sm pt-2 border-t border-slate-200/60">
                  <div>
                    <p className="text-[11px] font-semibold text-slate-400">Gross Total</p>
                    <p className="font-bold text-slate-900">${Number(order.total || 0).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-[11px] font-semibold text-rose-500">
                      Platform Fee ({order.commissionPercent || Math.round((Number(order.commission || 0) / (Number(order.total) || 1)) * 100)}%)
                    </p>
                    <p className="font-bold text-rose-600">-${Number(order.commission || 0).toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-[11px] font-semibold text-emerald-600">Supplier Net</p>
                    <p className="font-bold text-emerald-700">
                      ${Number((Number(order.total || 0) - Number(order.commission || 0)).toFixed(2))}
                    </p>
                  </div>
                </div>
                <div className="mt-2.5 flex items-center justify-between text-xs text-slate-500 pt-1.5 border-t border-slate-100">
                  <span>Payout Settlement Status:</span>
                  <span className="font-bold uppercase tracking-wider text-indigo-700">{order.payoutStatus || 'pending'}</span>
                </div>
              </div>

              {/* Mandatory Shipping & Packaging Label Specification Box */}
              <div className="rounded-xl border border-indigo-100 bg-indigo-50/25 p-4">
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Tag className="h-4 w-4 text-indigo-600" />
                    <p className="text-xs font-bold uppercase tracking-wide text-indigo-950">
                      Shipping & Packaging Label
                    </p>
                  </div>
                  <span className="rounded border border-indigo-200 bg-white px-2 py-0.5 font-mono text-xs font-bold text-indigo-700">
                    Ref: {order.orderLabelRef || order.orderNo}
                  </span>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-slate-700">
                  <div>
                    <span className="block text-[11px] text-slate-400">Merchant / Brand:</span>
                    <strong className="text-slate-900">{order.brandLabel || 'Sellvro Merchant'}</strong>
                  </div>
                  <div>
                    <span className="block text-[11px] text-slate-400">Item SKU:</span>
                    <strong className="font-mono text-indigo-800">{order.productSku || '—'}</strong>
                  </div>
                  <div className="col-span-2 border-t border-indigo-100/60 pt-1.5">
                    <span className="block text-[11px] text-slate-400">Packaging / Handling Notes:</span>
                    <span className="text-slate-800">{order.labelNotes || 'Standard handling instructions'}</span>
                  </div>
                  {order.shippingLabelUrl ? (
                    <div className="col-span-2 flex items-center justify-between border-t border-indigo-100/60 pt-1.5">
                      <span className="text-[11px] text-slate-400">External Shipping Label PDF:</span>
                      <a
                        href={mediaUrl(order.shippingLabelUrl)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline"
                      >
                        Open Airway Bill <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  ) : null}

                  <div className="col-span-2 border-t border-indigo-100/60 pt-2.5 flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setShowLabelModal(true)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 cursor-pointer"
                    >
                      <Printer className="h-3.5 w-3.5" />
                      View & Print 4x6 Airway Bill Label
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowThermalLabel((prev) => !prev)}
                      className="text-xs font-semibold text-indigo-700 hover:underline cursor-pointer"
                    >
                      {showThermalLabel ? 'Hide Quick Preview' : 'Quick Preview'}
                    </button>
                  </div>

                  {showThermalLabel && (
                    <div className="col-span-2 mt-3 rounded-lg border-2 border-dashed border-slate-800 bg-white p-3 font-mono text-slate-900 shadow-sm">
                      <div className="flex items-start justify-between border-b-2 border-slate-800 pb-2">
                        <div>
                          <h4 className="text-sm font-black tracking-tight">SELLVRO AIR EXPRESS</h4>
                          <p className="text-[9px] text-slate-600">STANDARD 4x6 INCH DROPSHIP LABEL</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[11px] font-black uppercase text-indigo-700">
                            {order.warehouseLocation === 'wms_hub' ? '🏢 WMS HUB' : '🏭 SUPPLIER'}
                          </p>
                          <p className="text-[9px] text-slate-500">REF: {order.orderLabelRef || order.orderNo}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 border-b-2 border-slate-800 py-2 text-[11px]">
                        <div>
                          <p className="text-[9px] font-bold uppercase text-slate-400">ORIGIN / CUSTODY:</p>
                          <p className="font-bold">
                            {order.warehouseLocation === 'wms_hub' ? 'Sellvro WMS Central Hub' : 'Supplier Facility Direct'}
                          </p>
                          <p className="text-[9px] text-slate-500">
                            Supplier: {formatSupplierId(order.supplierDisplayId || order.supplierId)}
                          </p>
                        </div>
                        <div>
                          <p className="text-[9px] font-bold uppercase text-slate-400">SHIP TO (DESTINATION):</p>
                          <p className="font-bold">{shipping?.fullName || order.user}</p>
                          <p className="text-[10px] text-slate-700">{shipping?.addressLine || '—'}</p>
                          <p className="text-[10px] text-slate-700">
                            {shipping?.city ? `${shipping.city}, ` : ''}{shipping?.state} {shipping?.postalCode}
                          </p>
                          <p className="text-[9px] text-slate-500">{shipping?.country || '—'} · Ph: {shipping?.phone || '—'}</p>
                        </div>
                      </div>

                      <div className="py-2 text-[11px]">
                        <div className="grid grid-cols-3 gap-1">
                          <div>
                            <span className="text-[9px] text-slate-400 block">SKU:</span>
                            <strong className="text-indigo-800">{order.productSku || '—'}</strong>
                          </div>
                          <div>
                            <span className="text-[9px] text-slate-400 block">QTY:</span>
                            <strong>{order.quantity || 1} PCS</strong>
                          </div>
                          <div>
                            <span className="text-[9px] text-slate-400 block">BRAND:</span>
                            <strong className="truncate block">{order.brandLabel || 'Merchant Store'}</strong>
                          </div>
                        </div>
                        <p className="mt-1 text-[10px] font-semibold text-slate-800 truncate">
                          Item: {order.product}
                        </p>
                        {order.labelNotes && (
                          <p className="text-[9px] italic text-slate-600 mt-0.5">Note: {order.labelNotes}</p>
                        )}
                      </div>

                      <div className="border-t-2 border-slate-800 pt-2 text-center">
                        <div className="flex h-8 items-center justify-center gap-[2px] bg-slate-50 px-2 py-0.5">
                          <span className="h-full w-1 bg-black"></span>
                          <span className="h-full w-0.5 bg-black"></span>
                          <span className="h-full w-1.5 bg-black"></span>
                          <span className="h-full w-0.5 bg-black"></span>
                          <span className="h-full w-1 bg-black"></span>
                          <span className="h-full w-2 bg-black"></span>
                          <span className="h-full w-0.5 bg-black"></span>
                          <span className="h-full w-1 bg-black"></span>
                          <span className="h-full w-0.5 bg-black"></span>
                          <span className="h-full w-1.5 bg-black"></span>
                          <span className="h-full w-1 bg-black"></span>
                          <span className="h-full w-2 bg-black"></span>
                          <span className="h-full w-0.5 bg-black"></span>
                          <span className="h-full w-1.5 bg-black"></span>
                        </div>
                        <p className="mt-0.5 text-[8px] tracking-widest text-slate-600">
                          *{order.trackingNumber || order.orderNo}*
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Dynamic Fulfillment Mode Card (WMS Warehouse vs Self-Fulfillment) */}
              {order.isWmsOrder ? (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4 shadow-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Warehouse className="h-4 w-4 text-emerald-700" />
                      <p className="text-xs font-bold uppercase tracking-wide text-emerald-950">
                        Sellvro WMS Warehouse Fulfillment
                      </p>
                    </div>
                    <span className="rounded-full bg-emerald-100 border border-emerald-300 px-2 py-0.5 font-mono text-[10px] font-bold text-emerald-800">
                      ⚡ WMS Order
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <span className="block text-[11px] text-slate-500">WMS Batch Number:</span>
                      <strong className="font-mono text-emerald-900">
                        {order.wmsBatchNumber || 'CBF-PENDING'}
                      </strong>
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-500">WMS Request #:</span>
                      <strong className="font-mono text-emerald-900">
                        {order.wmsRequestNumber || order.wmsFulfillmentId || '1-CBF-PENDING'}
                      </strong>
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-500">Warehouse Dispatch:</span>
                      <span className="inline-flex items-center gap-1 font-bold capitalize text-emerald-800">
                        <span className={`h-2 w-2 rounded-full ${order.isDispatched ? 'bg-emerald-600' : 'bg-amber-500 animate-pulse'}`} />
                        {order.isDispatched ? 'Dispatched' : (order.wmsStatus === 'pushed' ? 'Queued in Warehouse' : (order.wmsStatus || 'Pending'))}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-500">Tracking Status:</span>
                      <strong className="font-semibold capitalize text-indigo-800">
                        {order.wmsTrackingStatus ? order.wmsTrackingStatus.replace(/_/g, ' ') : (order.trackingStatus || 'Awaiting Pickup')}
                      </strong>
                    </div>
                    {order.wmsTrackingStatusDetail && (
                      <div className="col-span-2 rounded bg-white/70 p-2 border border-emerald-100 text-[11px]">
                        <span className="text-slate-500 font-medium">Status Detail: </span>
                        <span className="text-slate-800 font-semibold">{order.wmsTrackingStatusDetail}</span>
                      </div>
                    )}
                    {order.wmsDispatchProofUrl && (
                      <div className="col-span-2">
                        <a
                          href={order.wmsDispatchProofUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-900 underline"
                        >
                          <ExternalLink className="h-3 w-3" /> View Warehouse Dispatch Proof
                        </a>
                      </div>
                    )}
                    {order.dispatchedAt && (
                      <div className="col-span-2 text-[11px] text-slate-500">
                        Dispatched At: <strong className="text-slate-800">{new Date(order.dispatchedAt).toLocaleString()}</strong>
                      </div>
                    )}
                    {order.wmsPushedAt && (
                      <div className="col-span-2 border-t border-emerald-100/60 pt-1 text-[11px] text-slate-500">
                        Registered in WMS at:{' '}
                        <strong className="text-slate-800">
                          {new Date(order.wmsPushedAt).toLocaleString()}
                        </strong>
                      </div>
                    )}
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-emerald-100 flex items-center justify-between">
                    <span className="text-[11px] text-emerald-800 font-medium">
                      {liveTrackSuccess || 'Inventory deducted live from WMS'}
                    </span>
                    <button
                      type="button"
                      onClick={handleLiveTrack}
                      disabled={trackingLive}
                      className="inline-flex items-center gap-1 rounded-md bg-emerald-700 px-2.5 py-1 text-xs font-semibold text-white hover:bg-emerald-800 transition disabled:opacity-60 shadow-2xs cursor-pointer"
                    >
                      <RefreshCw className={`h-3 w-3 ${trackingLive ? 'animate-spin' : ''}`} />
                      {trackingLive ? 'Syncing...' : 'Live WMS Tracking'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="rounded-xl border border-blue-200 bg-blue-50/50 p-4 shadow-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Building2 className="h-4 w-4 text-blue-700" />
                      <p className="text-xs font-bold uppercase tracking-wide text-blue-950">
                        Self-Fulfillment (Supplier Facility Direct)
                      </p>
                    </div>
                    <span className="rounded-full bg-blue-100 border border-blue-300 px-2.5 py-0.5 text-[11px] font-bold text-blue-800">
                      🏭 Self-Fulfilled
                    </span>
                  </div>

                  <div className="mt-3 grid grid-cols-2 gap-2.5 text-xs">
                    <div>
                      <span className="block text-[11px] text-slate-500">Physical Stock Location:</span>
                      <strong className="text-slate-900">Supplier Private Facility</strong>
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-500">Fulfillment Mode:</span>
                      <strong className="text-blue-900">Direct Courier Handover</strong>
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-500">Custody Status:</span>
                      <span className="inline-flex items-center gap-1 font-bold text-slate-800">
                        <span className="h-2 w-2 rounded-full bg-blue-600" />
                        {order.warehouseLocation === 'in_transit'
                          ? 'In Courier Transit'
                          : order.warehouseLocation === 'delivered'
                            ? 'Delivered to Customer'
                            : 'In Supplier Warehouse'}
                      </span>
                    </div>
                    <div>
                      <span className="block text-[11px] text-slate-500">Promised Handling Time:</span>
                      <strong className="text-emerald-700">{order.promisedHandlingTime || 'Within 24 Hours'}</strong>
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-blue-200/70 text-[11px] text-blue-950 font-medium">
                    📦 Product is stored at your own facility. Pack the items, attach shipping label, and hand over to courier partner.
                  </div>
                </div>
              )}

              {/* Live Parcel Tracking */}
              <div className="rounded-xl border border-indigo-100 bg-indigo-50/30 p-4">
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-xs font-semibold uppercase tracking-wide text-indigo-900">
                    Live Parcel Tracking
                  </p>
                  <span className="rounded border border-indigo-200 bg-white px-2 py-0.5 font-mono text-xs font-bold text-indigo-700">
                    {order.trackingNumber && !order.trackingNumber.startsWith('SLV-') ? order.trackingNumber : 'Awaiting Tracking ID'}
                  </span>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-slate-700">
                  <div>
                    <span className="block text-[11px] text-slate-400">Carrier:</span>
                    <strong className="text-slate-900">{order.carrier || 'Sellvro Express'}</strong>
                  </div>
                  <div>
                    <span className="block text-[11px] text-slate-400">Dispatch Status:</span>
                    <strong className="capitalize text-indigo-700">{order.trackingStatus || order.status}</strong>
                  </div>
                  <div className="col-span-2 border-t border-indigo-100/50 pt-1">
                    <span className="block text-[11px] text-slate-400">Est. Delivery:</span>
                    <span className="font-medium text-slate-800">{order.estimatedDelivery || '3 - 5 Business Days'}</span>
                  </div>
                  <div className="col-span-2 pt-2 border-t border-indigo-100/60 flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => setTrackingModalOpen(true)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white hover:bg-indigo-700 transition shadow-2xs"
                    >
                      <Truck className="h-3.5 w-3.5" />
                      Shipment Timeline
                    </button>

                    {order.status !== 'cancelled' && (
                      <button
                        type="button"
                        onClick={() => setUpdateTrackingOpen(true)}
                        className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-2xs"
                      >
                        <Plus className="h-3.5 w-3.5" />
                        {order.trackingNumber ? 'Update Tracking ID' : 'Add Tracking ID'}
                      </button>
                    )}

                    {order.status !== 'cancelled' &&
                      !['in_transit', 'out_for_delivery', 'delivered'].includes((order.trackingStatus || '').toLowerCase()) &&
                      !order.isDispatched &&
                      order.warehouseLocation !== 'in_transit' &&
                      order.warehouseLocation !== 'delivered' && (
                        <button
                          type="button"
                          onClick={() => setCancelModalOpen(true)}
                          className="inline-flex items-center gap-1.5 rounded-lg border border-rose-300 bg-rose-50 px-3 py-1.5 text-xs font-bold text-rose-700 hover:bg-rose-100 transition shadow-2xs"
                        >
                          <Ban className="h-3.5 w-3.5" />
                          Cancel Order
                        </button>
                      )}

                    {getCourierExternalTrackingUrl(order.carrier, order.trackingNumber) && (
                      <a
                        href={getCourierExternalTrackingUrl(order.carrier, order.trackingNumber)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 rounded-lg border border-blue-600 bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-700 hover:bg-blue-100 transition shadow-2xs"
                      >
                        <span>Track on {order.carrier || 'Courier'}</span>
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    )}

                    {showStatusUpdate && (
                      <button
                        type="button"
                        onClick={() => setCourierModalOpen(true)}
                        className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 hover:text-blue-900 underline ml-auto"
                      >
                        Handover Courier
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Shipping Address */}
              <div className="rounded-xl border border-slate-100 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                  Shipping address
                </p>
                <p className="mt-2 whitespace-pre-line text-sm text-slate-700">
                  {hasShippingAddress(shipping) ? formatShippingAddress(shipping) : 'No address on file'}
                </p>
              </div>

              {/* Admin / Supplier Status & Custody Location Updater */}
              {showStatusUpdate && (
                <div className="space-y-3 rounded-xl border border-slate-200 bg-slate-50/60 p-4">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                      Dispatch & Courier Management
                    </p>
                    <span className="text-[10px] font-bold text-indigo-700 uppercase">
                      {order.warehouseLocation === 'wms_hub' ? 'WMS Fulfilled' : 'Supplier Fulfilled'}
                    </span>
                  </div>

                  {/* Primary Handover to Courier Button */}
                  <Button
                    type="button"
                    size="sm"
                    fullWidth
                    onClick={() => setCourierModalOpen(true)}
                    className="bg-blue-600 hover:bg-blue-700 text-white font-bold shadow-md shadow-blue-500/20 py-2.5"
                  >
                    <Truck className="h-4 w-4 mr-1.5" />
                    Handover to Courier / Dispatch Parcel
                  </Button>

                  <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2 pt-2 border-t border-slate-200/80">
                    <div>
                      <label className="mb-1 block text-[11px] font-medium text-slate-600">Order Status</label>
                      <select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                        className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
                      >
                        {ORDER_STATUS_OPTIONS.map((option) => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="mb-1 block text-[11px] font-medium text-slate-600">Warehouse Custody</label>
                      <select
                        value={warehouseLoc}
                        onChange={(e) => setWarehouseLoc(e.target.value)}
                        className="h-10 w-full rounded-lg border border-slate-200 bg-white px-3 text-sm text-slate-700 focus:border-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-100"
                      >
                        <option value="supplier_warehouse">🏭 At Supplier Warehouse</option>
                        {order.isWmsOrder && <option value="wms_hub">🏢 At WMS Central Hub</option>}
                        <option value="in_transit">🚚 In Courier Transit</option>
                        <option value="delivered">✅ Delivered to Customer</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button
                      type="button"
                      size="sm"
                      fullWidth
                      disabled={saving || (status === order.status && warehouseLoc === order.warehouseLocation)}
                      onClick={handleStatusUpdate}
                    >
                      {saving ? 'Updating…' : 'Save Status & Custody Location'}
                    </Button>
                    {order.isWmsOrder && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        fullWidth
                        disabled={pushingWms}
                        onClick={handlePushWms}
                        className="border-emerald-300 text-emerald-800 hover:bg-emerald-50"
                      >
                        <Warehouse className="h-3.5 w-3.5 mr-1 text-emerald-600" />
                        {pushingWms
                          ? 'Pushing to WMS…'
                          : 'Re-Sync with WMS Warehouse'}
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          ) : (
            !loading && <p className="text-sm text-slate-500">Order not found.</p>
          )}
        </div>
      </aside>

      {/* Interactive Tracking Modal */}
      {order && (
        <TrackingModal
          order={order}
          open={trackingModalOpen}
          onClose={() => setTrackingModalOpen(false)}
        />
      )}

      {/* Courier Handover Modal */}
      {order && (
        <CourierHandoverModal
          order={order}
          open={courierModalOpen}
          onClose={() => setCourierModalOpen(false)}
          onSuccess={(next) => {
            setOrder(next)
            setStatus(next.status || status)
            setWarehouseLoc(next.warehouseLocation || warehouseLoc)
            onUpdated?.(next)
          }}
        />
      )}

      {/* Order Review Modal */}
      {reviewModalOpen && order && (
        <OrderReviewModal
          order={order}
          open={reviewModalOpen}
          onClose={() => setReviewModalOpen(false)}
          onSuccess={() => {
            loadOrder()
            onUpdated?.()
          }}
        />
      )}

      {/* Customer Order Cancellation Modal */}
      {cancelModalOpen && order && (
        <UserCancelOrderModal
          order={order}
          open={cancelModalOpen}
          onClose={() => setCancelModalOpen(false)}
          onSuccess={() => {
            loadOrder()
            onUpdated?.()
          }}
        />
      )}

      {/* Enter Real Courier Tracking Modal */}
      {updateTrackingOpen && order && (
        <UserUpdateTrackingModal
          order={order}
          open={updateTrackingOpen}
          onClose={() => setUpdateTrackingOpen(false)}
          onSuccess={() => {
            loadOrder()
            onUpdated?.()
          }}
        />
      )}
      {/* Official 4x6 Courier Shipping Airway Bill Modal */}
      {showLabelModal && order && (
        <ShippingAirwayBillModal
          order={order}
          open={showLabelModal}
          onClose={() => setShowLabelModal(false)}
        />
      )}
    </div>
  )
}

export default OrderDetailDrawer
